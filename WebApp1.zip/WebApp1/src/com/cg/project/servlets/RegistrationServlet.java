package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Associate;

import sun.util.calendar.BaseCalendar.Date;

@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RegistrationServlet() {
		super();
	}

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateId =Integer.parseInt(request.getParameter("associateId"));
		String firstName =request.getParameter("firstname");
		String lastName =request.getParameter("lastname");
		String email =request.getParameter("email");
		String hobbies[] = request.getParameterValues("interest[]");
		String dateOfBirth = request.getParameter("dateOfbirth");
		String department =request.getParameter("dpt");
		String designation =request.getParameter("desg.");
		String password=request.getParameter("psw");
		String password2=request.getParameter("psw-repeat");
	
		Associate associate = new Associate(associateId, password, firstName, lastName, email, hobbies, department, designation, dateOfBirth);
    	RequestDispatcher dispatcher;
		if(password.equals(password2)){
			dispatcher = request.getRequestDispatcher("welcomePage.jsp");
    		request.setAttribute("associate", associate);
    		dispatcher.forward(request, response);
//			out.println("<font color=green> Welcome ");
//			out.println("<table><tr><td>associateId:</td> "+"<td>"+associateId+"</td></tr>");
//			out.println("<tr><td>name:</td> "+"<td>"+firstName+" "+lastName+"</td></tr>");
//			out.println("<tr><td>email: </td> "+"<td>"+email+"</td></tr>");
//			out.println("<tr><td>hobbies:</td> ");
//			out.print("<td>");
//			for (String h : hobbies)
//				out.print(" "+h);
//			out.print("</td></tr>");
//			out.println("<tr><td>DateofBirth: </td> "+"<td>"+dateOfBirth+"</td></tr>");
//			out.println("<tr><td>Department: </td> "+"<td>"+department+"</td></tr>");
//			out.println("<tr><td>Designation: </td> "+"<td>"+designation+"</td></tr></table>");
//			out.println("Your registration process is complete");
		}
		else
			dispatcher = request.getRequestDispatcher("errorPage1.jsp");
		request.setAttribute("errorMessage", "enter correct password");
		dispatcher.forward(request, response);
		}

	}



